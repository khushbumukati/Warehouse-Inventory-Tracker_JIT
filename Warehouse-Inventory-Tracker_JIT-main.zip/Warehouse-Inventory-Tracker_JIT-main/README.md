# Warehouse Inventory Tracker_JIT

Simple Java (no Maven) implementation of an event-based Warehouse Inventory Tracker.

## Project Structure
- src/com/warehouse/Main.java
- src/com/warehouse/model/Product.java
- src/com/warehouse/service/AlertService.java
- src/com/warehouse/service/RestockAlertService.java
- src/com/warehouse/core/Warehouse.java
- src/com/warehouse/core/WarehouseManager.java
- src/com/warehouse/persistence/InventoryPersistence.java
- inventory.txt  (created after first run)

## How to compile & run (simple Java)
1. Compile:

   ```bash
   javac -d out src/com/warehouse/**/*.java src/com/warehouse/*.java
   ```
2. Run:
   ```bash
   java -cp out com.warehouse.Main
   ```

## GitHub (you asked for a public repo named exactly: "Warehouse Inventory Tracker_JIT")
GitHub repo names usually avoid spaces; if you want the same exact name with spaces, create it via the web UI.

Common commands to push:
```bash
git init
git add .
git commit -m "Initial commit: Warehouse Inventory Tracker_JIT"
git branch -M main
git remote add origin https://github.com/<your-username>/Warehouse-Inventory-Tracker_JIT.git
git push -u origin main
```

(Replace `<your-username>` and repo URL as needed. Create the repo on GitHub first.
Alternatively use `gh repo create` if you have GitHub CLI.)

## Notes
- Observer pattern implemented via AlertService.
- Thread-safety: synchronized methods and ConcurrentHashMap.
- Persistence: very simple text (CSV-like) file.
